package com.voiceverse.app;
import android.app.*;import android.os.*;import android.speech.tts.*;import android.webkit.*;import android.widget.*;import android.content.*;import java.io.*;import java.util.*;
public class MainActivity extends Activity implements TextToSpeech.OnInitListener{
 WebView w;TextToSpeech t;boolean ready=false;
 public void onCreate(Bundle b){super.onCreate(b);t=new TextToSpeech(this,this);w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.addJavascriptInterface(new Bridge(),"AndroidVoice");w.setWebViewClient(new WebViewClient());setContentView(w);w.loadUrl("file:///android_asset/index.html");}
 public void onInit(int s){ready=s==TextToSpeech.SUCCESS;if(ready){t.setLanguage(Locale.getDefault());}}
 class Bridge{
 @JavascriptInterface public void speak(String x,float p,float r,String v){runOnUiThread(()->{if(!ready)return;select(v);t.setPitch(p);t.setSpeechRate(r);t.speak(x,TextToSpeech.QUEUE_FLUSH,null,"preview");});}
 @JavascriptInterface public void stop(){runOnUiThread(()->t.stop());}
 @JavascriptInterface public void saveAudio(String x,float p,float r,String v){runOnUiThread(()->{if(!ready){toast("Speech engine is loading.");return;}select(v);t.setPitch(p);t.setSpeechRate(r);File d=new File(getExternalFilesDir(null),"VoiceVerse");d.mkdirs();File f=new File(d,"VoiceVerse-"+System.currentTimeMillis()+".wav");int q=t.synthesizeToFile(x,new HashMap<>(),f,"voiceverse-export");if(q==TextToSpeech.ERROR)toast("Audio export failed.");else toast("Creating WAV. Find it in Android/data/com.voiceverse.app/files/VoiceVerse");});}
 @JavascriptInterface public void shareText(String x){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,x);startActivity(Intent.createChooser(i,"Share text"));});}
 }
 void select(String n){if(n==null||n.isEmpty())return;for(Voice v:t.getVoices())if(v.getName().equals(n)){t.setVoice(v);break;}}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 protected void onDestroy(){if(t!=null){t.stop();t.shutdown();}super.onDestroy();}
}
